# Handoff: Profiles Section Redesign ("Channels & Code")

## Overview
Redesign of the social-links list currently at the top of the petrol "What I do" gallery section in the portfolio-vue site (`portfolio/src/views/Gallery.vue`). It becomes its own full-page section on a magenta background featuring YouTube (3 channels, one shared card) and GitHub (live recent repos) as two white cards, plus a row of circular secondary links (Twitch, DeviantArt, Logopond, Freesound). LinkedIn intentionally excluded (goes to footer). Content is hardcoded per channel — no list-driven config like the old `profiles` array.

## About the Design Files
`Profiles Section.dc.html` is a **design reference created in HTML** — a prototype showing intended look and behavior, NOT production code. The task is to **recreate design `2a` as a Vue single-file component** in the existing portfolio-vue codebase (Vue 2 + SCSS, `portfolio/src`), following its established patterns: `ViewContainer`-style section, curved-border divider, SCSS variables/mixins, Font Awesome 5.5 icons.

The chosen design is the option labeled **2a** in the file (topmost section). Options 2b, 2c, 1a–1c are rejected explorations — ignore them, except 2c which shows the future YouTube-API variant (see below).

## Fidelity
**High-fidelity.** Layout, spacing, typography and colors are final. Recreate pixel-perfectly, but express all values through the existing SCSS variable system (see Design Tokens).

## Section anatomy
1. Petrol strip above (belongs to the previous section) + the site's standard curved border, magenta fill: use the existing `curved-border($color-magenta, up)` mixin — do NOT re-implement the SVG.
2. Magenta section body (`$color-magenta`), padding `2rem 3rem 5rem` (mobile: `2rem 1rem 4rem`).
3. Heading: Cookie (`$font-serif`), 4.2rem (~`$fontsize-xxl`), color `#f6e3ea` (suggest new var `$color-magenta-text-bright`), centered.
4. Intro paragraph: Open Sans (`$font-base`), `$fontsize-m`, line-height 1.6, color `#f2cdda` (suggest `$color-magenta-text`), centered, max-width 560px.
   Copy: "Beyond client work, I publish things — videos, music and open source. This is where to find them."
5. Two-card grid.
6. Secondary icon row.

## Two-card grid — golden ratio
```scss
.profiles-grid {
  display: grid;
  grid-template-columns: #{$gn}fr 1fr; // 1.618fr 1fr — $gn already exists in variables.scss
  gap: 32px;
  max-width: $width-content-max; // 960-1120px; prototype uses 1120
  margin: 0 auto;
  // cards stretch to equal height (grid default align-items: stretch)

  @include viewport-mobile {
    grid-template-columns: 1fr; // stack: YouTube card first, GitHub below
    gap: 20px;
  }
}
```
Both cards are equal height on desktop; GitHub card's "All repos" button uses `margin-top: auto` inside a flex column to pin to the bottom. GitHub shows one entry fewer than YouTube (3 repos vs 3 channels) so content balances.

## Card: YouTube (left, wide column)
- White card: background `#ffffff`, border-radius 8px, padding 28px 30px, shadow `0 4px 14px rgba(0,0,0,0.25)`.
- Header row: `fab fa-youtube` icon 24px in `$color-magenta`; title "YOUTUBE" — Oswald (`$font-condensed`), 20px, uppercase, letter-spacing 1.5px, color `#2f3a3f`; right-aligned monospace caption "3 channels" 11px `#9aa5aa`. Bottom border `2px solid #f2cdda`, padding-bottom 14px.
- Three channel rows (each an `<a target="_blank">`), padding 22px 4px, separated by `1px solid #eef1f2`:
  - Avatar 70px circle (object-fit cover). Channels:
    1. **Yummie Plays** `@yummieplays` → https://www.youtube.com/@yummieplays — avatar `src/assets/svg/yummie.png` — "Gaming & game development — let's-plays, devlogs and hands-on guides where I take games apart and build new ones."
    2. **Manuel Graf Music** `@manuelgrafmusic` → https://www.youtube.com/@manuelgrafmusic — avatar: placeholder = `bildmarke-inverted.svg` on `$color-magenta` circle; replace with real channel avatar when available — "My original music — compositions, game scores and studio sessions, from first sketch to finished track."
    3. **Manuel F. Graf** `@manuelfgraf` → https://www.youtube.com/@manuelfgraf — avatar `portrait-comc-expanded.png` — "The personal channel — talks, experiments and everything that doesn't fit neatly anywhere else."
  - Name: Oswald 19px `#2f3a3f`; handle inline after name: monospace 11.5px `$color-magenta`.
  - Description: Open Sans 13.5px, line-height 1.6, color `#4a565c`.
  - Hover: `translateX(5px)`, background `#fdf4f8`, transition `$duration-instant`–`0.2s` ease.
  - Mobile: keep row layout but allow avatar 56px and description to wrap; min tap height ≥ `$min-tap`.

## Card: GitHub (right, narrow column)
- Same white card styling; flex column.
- Header row like YouTube's: `fab fa-github`, "GITHUB", right caption shows data status (see Behavior).
- 3 repo entries (recently active, non-fork), each an `<a target="_blank">`, padding 14px 4px, border-bottom `1px solid #eef1f2`:
  - Repo name: Oswald 16px `#2f3a3f`.
  - Description: 13px `#4a565c` (fallback "No description yet.").
  - Meta row (monospace 11px `#9aa5aa`): language dot (9px circle, GitHub language color) + language name, "updated Mon YYYY".
  - Hover: same translateX/pink-bg as YouTube rows.
- Bottom button pinned via `margin-top: auto`: full-width, background `$color-magenta`, white bold uppercase 13px, radius 5px, padding 11px; hover `$color-magenta-dark`. Label "All repos on GitHub" → https://github.com/ManuelGraf.

## Secondary links row
Contact-section style: circular icon + label below, centered row, `gap: 52px` (mobile: wrap, gap 28px), margin-top 4rem.
- Circle: 54px (≥ `$min-tap`), white background, `$color-magenta` icon 23px, shadow `0 2px 8px rgba(0,0,0,0.2)`.
- Label: Oswald 14px, letter-spacing 0.5px, color `#f2cdda`; hover: whole link `translateY(-4px)`, label white.
- Links: Twitch `fab fa-twitch` https://twitch.tv/yumyumyummieee/ · DeviantArt `fab fa-deviantart` https://www.deviantart.com/yummieee · Logopond `fas fa-pencil-alt` https://logopond.com/yummie/profile/17039 · Freesound `fas fa-music` https://freesound.org/people/yummie/

## Interactions & Behavior
- All links open in new tab (`target="_blank" rel="noopener"`).
- Hover transitions: 0.2s ease on transform/background (site's `$duration-instant`/`$duration-noticeable` range).
- **GitHub live data**: on mount, `GET https://api.github.com/users/ManuelGraf/repos?sort=pushed&per_page=12` (no auth needed, 60 req/h per IP). Filter `!fork`, take first 3. Map: `name`, `html_url`, `description`, `language`, `pushed_at` → "Mon YYYY".
- States: while loading show 3 skeleton rows (or the fallback); on fetch error fall back to a hardcoded snapshot array and set status caption to "cached snapshot" (live: "● live · GitHub API"). Cache the successful response in `localStorage` with a timestamp; reuse if < 1h old to stay under rate limits.
- Optional future (design 2c in the prototype): per-channel stat chips (subscribers / videos / latest upload) via YouTube Data API v3 `channels?part=statistics` — needs an API key; a serverless proxy or build-time fetch recommended so the key isn't exposed.

## Responsive behavior
- Use existing `viewport-mobile` / `viewport-tablet` mixins.
- Mobile (`viewport-mobile`): grid stacks to one column (golden ratio only applies ≥ tablet); section side padding 1rem; heading `$fontsize-xl`; secondary row wraps.
- Tablet+ (`viewport-tablet`, ≥960px): the 1.618fr/1fr grid as specified.

## State Management
Component-local state only: `repos: []`, `ghStatus: 'loading' | 'live' | 'snapshot'`. No Vuex needed. Channel data is a hardcoded const in the component.

## Design Tokens
Existing SCSS variables to use (from `assets/styles/variables.scss`):
- `$color-magenta` #cc145d (section bg), `$color-magenta-dark` (button hover), `$color-white`, `$font-base` Open Sans, `$font-condensed` Oswald, `$font-serif` Cookie, `$gn` 1.618, `$fontsize-*` scale, `$min-tap`, `$width-content-max`, `$duration-*`.

New variables to add (used repeatedly in this section):
```scss
$color-magenta-text: #f2cdda;         // body text on magenta
$color-magenta-text-bright: #f6e3ea;  // heading on magenta
$color-magenta-tint: #fdf4f8;         // row hover bg on white cards
$color-card-heading: #2f3a3f;         // card titles (near black-light)
$color-card-text: #4a565c;            // card body text
$color-card-muted: #9aa5aa;           // captions/meta
$color-card-divider: #eef1f2;         // row separators
$shadow-card: 0 4px 14px rgba(0, 0, 0, 0.25);
```
Font sizes in the prototype map roughly onto the golden-ratio scale; where a value falls between steps (e.g. 19px names), a pixel literal is acceptable or extend the scale.

GitHub language dot colors: JavaScript #f1e05a, TypeScript #3178c6, Vue #41b883, HTML #e34c26, CSS #563d7c, SCSS #c6538c, C# #178600, C++ #f34b7d, GDScript #355570, Python #3572A5, PHP #4F5D95, fallback #cfcfcf.

## Assets
- `src/assets/svg/yummie.png` — Yummie Plays avatar (already in repo)
- `src/assets/svg/portrait-comc-expanded.png` — personal channel avatar (already in repo)
- `src/assets/svg/bildmarke-inverted.svg` — placeholder for music channel avatar (replace with real one)
- Font Awesome 5.5 (already loaded): fa-youtube, fa-github, fa-twitch, fa-deviantart, fa-pencil-alt, fa-music, brands + solid

## Files in this bundle
- `Profiles Section.dc.html` — the design prototype. **Section `2a` (topmost) is the approved design.** 2b/2c/1a/1b/1c are explorations; 2c documents the YouTube-API stat-chip variant.
- `assets/` — the three avatar images used by the prototype.
